using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeController : MonoBehaviour
{
    public GameObject[] cubes;
    public float speed = 5;

    void Start()
    {
        cubes = new GameObject[3];
        cubes[0] = GameObject.Find("Cube1");
        cubes[1] = GameObject.Find("Cube2");
        cubes[2] = GameObject.Find("Cube3");
    }

    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 move = new Vector3(moveHorizontal, 0, moveVertical);

        foreach (GameObject cube in cubes)
        {
            cube.transform.position += move * speed * Time.deltaTime;

            //x
            if (cube.transform.position.x > 5)
            {
                cube.transform.position = new Vector3(5, cube.transform.position.y, cube.transform.position.z);
            }
            else if (cube.transform.position.x < -5)
            {
                cube.transform.position = new Vector3(-5, cube.transform.position.y, cube.transform.position.z);
            }

            //z
            if (cube.transform.position.z > 5)
            {
                cube.transform.position = new Vector3(cube.transform.position.x, cube.transform.position.y, 5);
            }
            else if (cube.transform.position.z < -5)
            {
                cube.transform.position = new Vector3(cube.transform.position.x, cube.transform.position.y, -5);
            }
        }
    }
}


